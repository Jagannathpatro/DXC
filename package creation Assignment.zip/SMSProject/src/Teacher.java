
public class Teacher {
public void takeclass()
{
	System.out.println("Teacher take class");
}
}
