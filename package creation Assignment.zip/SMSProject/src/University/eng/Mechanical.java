package University.eng;

public class Mechanical {
	public void eng() {
		System.out.println("mechanical");
	}

}
