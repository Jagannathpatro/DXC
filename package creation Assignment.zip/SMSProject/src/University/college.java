package University;

public class college {

public void attendLecture() {
	System.out.println("attend the lecture");
}

	}


