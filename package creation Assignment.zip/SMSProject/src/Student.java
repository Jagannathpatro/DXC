
public class Student {
	public void displayStudentdetails (){
		System.out.println("Display student details");
		Fee f = new Fee();
		f.takeFees();
		
	}

}
