import University.*;
import University.eng.Mechanical;
import games.*;

public class Client {
	public static void main(String[] args) {
		Student s =new Student();
		s.displayStudentdetails();
		Teacher t = new Teacher();
		t.takeclass();
		college c =new college();
		c.attendLecture();
		
		Cricket cc= new Cricket();
		cc.playcricket();
		
		Football f =new Football();
		f.playFootball();
		
		Mechanical m = new Mechanical();
		m.eng();
		
	}

}
