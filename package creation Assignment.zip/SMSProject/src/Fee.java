
public class Fee {
	public void takeFees() {
		System.out.println("Please pay the fees");
	}

}
