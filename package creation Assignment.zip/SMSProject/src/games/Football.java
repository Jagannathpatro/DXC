package games;

public class Football {
	public void playFootball() {
		System.out.println("playing football");
	}

}
